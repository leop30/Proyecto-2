class Tour:
  def __init__(self,dni,personas,precio_por_persona,descuento,start,precio_total):
    self.dni = dni
    self.personas = personas
    self.precio_por_persona = precio_por_persona
    self.descuento = descuento
    self.start = start
    self.precio_total=precio_total
  
  def mostrar(self):

    print(f"Cedula del registante: {self.dni}\nPersonas: {self.personas}\nPrecio por persona: {self.precio_por_persona}\nHora de inicio de la actividad: {self.start}\nPrecio Total a pagar: {self.precio_total}")