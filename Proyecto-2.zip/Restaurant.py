class Restaurant:
    def __init__(self,plato,price_iva,tipo):
      self.plato = plato
      self.price_iva =price_iva
      self.tipo = tipo

    def mostrar(self):
        print(f"Nombre del plato: {self.plato}\nTipo de plato: {self.tipo}\nPrecio del plato: {self.price_iva}")