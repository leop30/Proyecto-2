class Cruceros:
  def __init__(self,name,route,departure,cost,rooms,capacity):
        self.name = name
        self.route = route
        self.departure = departure 
        self.cost = cost
        self.rooms = rooms
        self.capacity = capacity


  def cruise_search (self):
    crucero=reponse.json()