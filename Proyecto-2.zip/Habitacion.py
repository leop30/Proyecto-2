class Habitacion:
  def __init__(self,letra,numero,tipo,ventaja,capacidad,persona):
    self.letra = letra
    self.numero = numero
    self.tipo=tipo
    self.ventaja =  ventaja
    self.capacidad = capacidad
    self.persona = persona

  def mostrar(self):

    print(f"Letra de la habitacion {self.letra}\nNumero: {self.numero}\nTipo de habitacion: {self.tipo} y {self.ventaja}\nCapacidad : {self.capacidad}\nPersona responsable: {self.persona}")