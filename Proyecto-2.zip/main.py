from Crucero import Cruceros 
from Habitacion import Habitacion
from Tour import Tour
from Restaurant import Restaurant
import requests
import string
import numpy as np

def api_saman_caribbean (param,inicio):
  
  url=f"https://saman-caribbean.vercel.app/api/cruise-ships"
  

  response = requests.request("GET",url)
  
  return response.json()

def cruise_search (inicio):
    crucero=api_saman_caribbean('search',inicio)
    for resultados in crucero:  
      print(f'''
      Nombre del barco: {resultados.get('name')}
      Ruta: {resultados.get('route')}
      Salida: {resultados.get('departure')}
      Costo del boleto: {resultados.get('cost')}
      Habitaciones: {resultados.get('rooms')}
      Capacidad de las habtaciones: {resultados.get('capacity')  }
      ''')
      
def ventas_tour (tours):
  while True:
    try:
      dni=int(input ("Por favor ingrse el dni del cliente:"))
      while True:
        try:
          seleccionador= int(input ("Por favor ingrese el tipo de tour (1)tour en el puerto, (2) Degustacion d  e comida local, (3)Trotar por el pueblo o ciudad,(4) Visita a lugares históricos: "))
          if seleccionador==1:
            while True:
              try:
                personas= int (input ("Por favor ingrese el numero de personas en el tour: "))
                precio_por_persona= 30 
                descuento= 0.1
                start= ("7:00 A.M.")
                if personas>=1 and personas<=2:
                  break
                elif personas>=3 and personas<=4:
                  precio_por_persona=precio_por_persona-(precio_por_persona*descuento)
                  break
                else:
                  print("numero de personas no valido ")
              except ValueError: 
                print("Tiene que ingresar un número")
            break
          elif seleccionador==2:
            while True:
              try:
                personas= int (input ("Por favor ingrese el numero de personas en el tour: ")) 
                precio_por_persona=100
                start= ("12:00 P.M.")
                if personas>=1 and personas<=2:
                  break
                else:
                  print("numero de personas no valido ")
              except ValueError: 
                print("Tiene que ingresar un número")
            break
          elif seleccionador==3:
            while True:
              try:
                personas= int (input ("Por favor ingrese el numero de personas en el tour: ")) 
                precio_por_persona=0
                descuento=0
                start= ("6:00 A.M.")
                if personas>=1:
                  break
                else:
                  print("numero de personas no valido ")
              except ValueError: 
                print("Tiene que ingresar un número")
            break
          elif seleccionador==4:
            while True:
              try:
                personas= int (input ("Por favor ingrese el numero de personas en el tour: ")) 
                precio_por_persona=40
                descuento=0.1
                start= ("10:00 A.M.")
                if personas>=1 and personas<=2:
                  break
                elif personas>=3:
                  precio_por_persona=precio_por_persona-(precio_por_persona*descuento)
                  break              
                else:
                  print("numero de personas no valido ")
              except ValueError: 
                print("Tiene que ingresar un número")
            break
          else: 
            print("Actividad no valida")
        except ValueError:
          print("Tiene que ingresar un número")
      break
    except ValueError: 
      print("Tiene que ingresar un número")
  precio_total=personas*precio_por_persona
  nuevo_tour = Tour(dni,personas,precio_por_persona,descuento,start,precio_total)
  tours.append(nuevo_tour)

  print("\n¡Tour registrado con éxito!")
  f=open("tour.txt","a")
  f.write('\n' + ("\n"*1))
  f.write(' Cedula: % s'%dni)
  f.write(' Personas: % s'%personas )
  f.write(' Precio por persona: % s'%precio_por_persona )
  f.write(' Descuento: % s'%descuento )
  f.write(' Hora de inicio: % s'%start )
  f.write(' Precio total a pagar: % s'%precio_total )
  f.close ()
  nuevo_tour.mostrar()

  return tours

def buscar_habitacion (habitaciones):
  while True:
    rooms={"simple":[4,10],"premium":[3,9],"vip":[1,6]}
    keys= rooms.keys()
    capacity={"simple":2,"premium":4,"vip":8}
    persona= str(input ("Ingrese el apellido de la familia o del huesped:"))

    try:
      tipo_habitacion=int(input("Por favor ingrese el tipo de habitacion 1(simple), 2(premium) y 3(vip): "))
      if tipo_habitacion==1:
        numero=11
        letra=rooms['simple'][0]
        numero-=rooms['simple'][1]
        capacidad=capacity['simple']
        tipo= ("Simple")
        ventaja=("Si puede tener servicio a la habitación")
        break
      elif tipo_habitacion==2:
        letra=rooms['premium'][0]
        numero=rooms['premium'][1]
        capacidad=capacity['premium']
        tipo= ("Premium")
        ventaja=("Si posee vista al mar")
        break
      elif tipo_numero==3:
        letra=rooms['vip'][0]
        numero=rooms['vip'][1]
        capacidad=capacity['simple']
        tipo= ("Vip")
        ventaja=("Si puede albergar fiestas privadas")
        break
      else: 
        print("Valor invalido")
 
    except ValueError: 
      print("Tiene que ingresar un número")

  num2alpha=dict(zip(range(1,27),string.ascii_lowercase))
  habitaciones_por_letra= list(range(1, numero+1))
  pasillos=list(range(1, letra+1))
  print (habitaciones_por_letra)
  print (pasillos)
  nuevo_habitacion = Habitacion(letra,numero,tipo,ventaja,capacidad,persona)
  habitaciones.append(nuevo_habitacion)
  print("\n¡Habitacion registrada con éxito!")
  nuevo_habitacion.mostrar()
  f=open("habitaciones.txt","a")
  f.write('\n' + ("\n"*1))
  f.write(' Letra de la habitacion: % s'%letra)
  f.write(' Numero de la habitacion: % s'%numero)
  f.write(' Tipo de habitacion: % s'%tipo)
  f.write(' Ventaja de la habitacion: % s'%ventaja)
  f.write(' Capacidad de la habitacion: % s'%capacidad)
  f.write(' Persona encargada: % s'%persona)
  f.close ()

  return habitaciones

def buscar_habitacion_particular(habitaciones) :
  palabra= str(input ("Por favor ingrese el numero de la habitacion: "))
  ocurrencias = []
  with open('habitacion.txt') as lineas:
    for linea in lineas:
      if palabra in linea:
        (ocurrencias.append(linea))
        print (ocurrencias)


def registrar_plato (platos):
  sells=[{"name":"Coca Cola","price":5.99,"amount":100},{"name":"Pasta","price":12.99,"amount":150},{"name":"Hamburguesa","price":13.99,"amount":230},{"name":"Donas","price":2.99,"amount":110},{"name":"Ron","price":11.99,"amount":250}]
  comidas = ["Coca Cola", "Pasta", "Hamburguesa", "Donas", "Ron"]
  for i,t in enumerate(comidas):
    print(f"{i+1}. {t}")

  plato = input("Introduzca el número correspondiente al plato de la persona: ")
  while (not plato.isnumeric()) or (int(plato) not in range(len(comidas)+1)):
    plato = input("Por favor ingrese un valor válido: ")
  for i,t in enumerate(comidas):
    if plato == str(i+1):
      plato = t
  for elementos in sells:
    a=elementos
    name = a.get('name', [])
    if name==plato:
      tipo1=["Alimento","Bebida"]
      for i,t in enumerate(tipo1):
        print(f"{i+1}. {t}")
      tipo = input("Introduzca el número correspondiente al plato de la persona: ")
      while (not tipo.isnumeric()) or (int(tipo) not in range(len(tipo1)+1)):
        tipo = input("Por favor ingrese un valor válido: ")
      for i,t in enumerate(tipo1):
        if tipo == str(i+1):
          tipo = t
          price= a.get('price', [])
          price_iva=price+(price*0.16)
  nuevo_plato = Restaurant(plato,price_iva,tipo)
  platos.append(nuevo_plato)
  print("\n¡Plato registrada con éxito!")
  nuevo_plato.mostrar()
  f=open("platos.txt","a")
  f.write('\n' + ("\n"*1))
  f.write(' Plato: % s'%plato)
  f.write(' Precio con iva: % s'%price_iva)
  f.write(' Tipo: % s'%tipo)
  f.close ()
  return platos


def buscar_plato(platos):
  while True:
    print("\n1. Busqueda por nombre del plato\n2. Busqueda por precio\n")
    opcion = input("Ingrese el número correspondiente a su selección: ")
    while (not opcion.isnumeric()) or (int(opcion) not in range(1,3)):
      opcion= input("Por favor ingrese un valor válido: ")
    print("\n")
    if(opcion == "1"):
      palabra= str(input ("Por favor ingrese el nombre del alimento: "))
      ocurrencias = []
      with open('platos.txt') as lineas:
        for linea in lineas:
          if palabra in linea:
            (ocurrencias.append(linea))
            print (ocurrencias)
      break
    elif (opcion == "2"):
      palabra= str(input ("Por favor ingrese el nombre del alimento: "))
      ocurrencias = []
      with open('platos.txt') as lineas:
        for linea in lineas:
          if palabra in linea:
            ocurrencias.append(linea)
            print (ocurrencias)
      break
    else:
	    print("Seleccione una opcion valida")


def eliminar_plato(platos):
  f = open("platos.txt","r")
  lines = f.readlines()
  f.close()
  f = open("yourfile.txt","w")
  for line in lines:
    if line!="Pasta"+"\n":
      f.write(line)
  f.close()
  print (line)

def registrar_combo(platos): 
  sells=[{"name":"Coca Cola","price":5.99,"amount":100},{"name":"Pasta","price":12.99,"amount":150},{"name":"Hamburguesa","price":13.99,"amount":230},{"name":"Donas","price":2.99,"amount":110},{"name":"Ron","price":11.99,"amount":250}]
  comidas = ["Coca Cola", "Pasta", "Hamburguesa", "Donas", "Ron"]
  for i,t in enumerate(comidas):
    print(f"{i+1}. {t}")

  plato = input("Introduzca el número correspondiente al plato de la persona: ")
  while (not plato.isnumeric()) or (int(plato) not in range(len(comidas)+1)):
    plato = input("Por favor ingrese un valor válido: ")
  plato = input("Introduzca el número correspondiente al plato de la persona: ")
  while (not plato.isnumeric()) or (int(plato) not in range(len(comidas)+1)):
    plato = input("Por favor ingrese un valor válido: ")  
  for i,t in enumerate(comidas):
    if plato == str(i+1) and plato==str(i+1):
      plato = t
  for elementos in sells:
    a=elementos
    name = a.get('name', [])
    if name==plato:
      tipo1=["Alimento","Bebida"]
      for i,t in enumerate(tipo1):
        print(f"{i+1}. {t}")
      tipo = input("Introduzca el número correspondiente al plato de la persona: ")
      while (not tipo.isnumeric()) or (int(tipo) not in range(len(tipo1)+1)):
        tipo = input("Por favor ingrese un valor válido: ")
        if name==plato:
          tipo2=["Alimento","Bebida"]
          for i,t in enumerate(tipo1):
            print(f"{i+1}. {t}")
          tipo = input("Introduzca el número correspondiente al plato de la persona: ")
          while (not tipo.isnumeric()) or (int(tipo) not in range(len(tipo2)+1)):
            tipo = input("Por favor ingrese un valor válido: ")
          for i,t in enumerate(tipo2):
            if tipo == str(i+1):
              tipo = t
              price= a.get('price', [])
              price_iva=price+(price*0.16)
            
      for i,t in enumerate(tipo1):
          if tipo == str(i+1):
            tipo = t
            price= a.get('price', [])
            price_iva=price+(price*0.16)
  nuevo_combo = Restaurant(plato,price_iva,tipo)
  platos.append(nuevo_combo)
  print("\n¡Plato registrada con éxito!")
  nuevo_combo.mostrar()
  f=open("platos.txt","a")
  f.write('\n' + ("\n"*1))
  f.write(' Plato: % s'%plato)
  f.write(' Precio con iva: % s'%price_iva)
  f.write(' Tipo: % s'%tipo)
  f.close ()
  return platos


def main():
  inicio= "a"
  print("¡Bienvenido a l sistema de Saman Caribbean!")
  while True:
    print("\n1. Modulo de gestión de cruceros\n2. Módulo de gestión de habitaciones\n3. Módulo de venta de tours\n4. Módulo de gestion de restaurante\n5. Módulo de estadistica\n")
    opcion = input("Ingrese el número correspondiente a su selección: ")
    while (not opcion.isnumeric()) or (int(opcion) not in range(1,6)):
      opcion= input("Por favor ingrese un valor válido: ")
    print("\n")

    if(opcion == "1"):
      cruise_search (inicio)
    elif(opcion == "2"):
      habitaciones = []
      print("Bienvenido a la reserva de habitacion")
      while True:
            print("\n1. Habitaciones\n2. Vender habitacion\n3. Desocupar habitacion\n4. Buscar habitacion particular \n")
            seleccion = input("Ingrese el número correspondiente a su selección: ")
            while (not seleccion.isnumeric()) or (int(seleccion) not in range(1,5)):
              seleccion = input("Por favor ingrese un valor válido: ")
            if int(seleccion) == 1:
              buscar_habitacion (habitaciones)     
            elif int(seleccion)== 2:
              vender_habitacion(habitaciones)
            elif int(seleccion)==3:
              desocupar_habitacion(habitaciones)
            elif int(seleccion)==4:
              buscar_habitacion_particular(habitaciones)
            else:
              print ("¡No hay platos ni combos!")
            otro = input("\n¿Desea realizar alguna otra operación?('S' para 'sí', 'N' para 'no'): ")
            while (otro.upper() != 'S') and (otro.upper() != 'N'):
              otro = input("Por favor ingrese un valor válido: ")
            if otro.upper() == "S":
              continue
            else:
              break
    elif(opcion == "3"):
      tours = []
      print("Bienvenido a la reserva de Tour")
      ventas_tour(tours)
    elif(opcion == "4"):
      platos=[]
      combos=[]
      print ("Bienvenido al restaurant")
      while True:
            print("\n1. Agregar plato\n2. Eliminar plato del menu\n3. Modificar producto del menu\n4. Agregar combo\n5. Buscar producto por nombre o rango de precio\n6. Buscar combo por nombre o rango de precio\n")
            seleccion = input("Ingrese el número correspondiente a su selección: ")
            while (not seleccion.isnumeric()) or (int(seleccion) not in range(1,6)):
              seleccion = input("Por favor ingrese un valor válido: ")
            if int(seleccion) == 1:
              registrar_plato (platos)   
            elif int(seleccion)== 2:
              eliminar_plato(platos)
            elif int(seleccion)==3:
              modificar_plato (platos)
            elif int(seleccion)==4:
              agregar_combo (combos)
            elif int(seleccion)== 5:
              buscar_plato(platos)
              if len(platos) == 0:
                print("Todavía no hay platos registrados")
            elif int(seleccion)==6:
              buscar_combo (platos)
            else:
              print ("¡No hay platos ni combos!")
            otro = input("\n¿Desea realizar alguna otra operación?('S' para 'sí', 'N' para 'no'): ")
            while (otro.upper() != 'S') and (otro.upper() != 'N'):
              otro = input("Por favor ingrese un valor válido: ")
            if otro.upper() == "S":
              continue
            else:
              break
    elif(opcion == "5"):
      estadisticas()
    else:
	    print("Seleccione una opcion valida")

    otro = input("\n¿Desea realizar alguna otra operación?('S' para 'sí', 'N' para 'no'): ")
    while (otro.upper() != 'S') and (otro.upper() != 'N'):
      otro = input("Por favor ingrese un valor válido: ")
    if otro.upper() == "S":
      continue
    else:
      break

	    
main ()